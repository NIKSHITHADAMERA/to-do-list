let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

function renderTasks() {
  const list = document.getElementById('taskList');
  list.innerHTML = '';

  const searchTerm = document.getElementById('searchInput').value.toLowerCase();

  tasks
    .filter(task => task.text.toLowerCase().includes(searchTerm))
    .forEach((task, index) => {
      const li = document.createElement('li');
      if (task.completed) li.classList.add('completed');

      const taskInfo = document.createElement('div');
      taskInfo.className = 'task-info';
      taskInfo.innerHTML = `<span>${task.text}</span><span class="task-due">Due: ${task.dueDate || 'None'}</span>`;

      const controls = document.createElement('div');

      const checkBtn = document.createElement('button');
      checkBtn.textContent = task.completed ? '🔄' : '✅';
      checkBtn.onclick = () => toggleComplete(index);

      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '🗑️';
      deleteBtn.onclick = () => deleteTask(index);

      controls.appendChild(checkBtn);
      controls.appendChild(deleteBtn);

      li.appendChild(taskInfo);
      li.appendChild(controls);

      list.appendChild(li);
    });

  localStorage.setItem('tasks', JSON.stringify(tasks));
}

function addTask() {
  const text = document.getElementById('taskInput').value.trim();
  const dueDate = document.getElementById('dueDate').value;

  if (!text) return alert('Enter a task!');

  tasks.push({ text, dueDate, completed: false });
  document.getElementById('taskInput').value = '';
  document.getElementById('dueDate').value = '';
  renderTasks();
}

function toggleComplete(index) {
  tasks[index].completed = !tasks[index].completed;
  renderTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  renderTasks();
}

function filterTasks() {
  renderTasks();
}

function toggleTheme() {
  document.body.classList.toggle('dark');
  localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
}

// Load theme on startup
if (localStorage.getItem('theme') === 'dark') {
  document.body.classList.add('dark');
}

renderTasks();
